from django.apps import AppConfig


class WearhouseConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'wearhouse'
    def ready(self):
        import wearhouse.signals
