from django.contrib import admin

from profileapp.models import BusinessProfile

# Register your models here.
admin.site.register(BusinessProfile)