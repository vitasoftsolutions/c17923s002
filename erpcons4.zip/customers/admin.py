from django.contrib import admin

from customers.models import CustomerBeneficaries

# Register your models here.
admin.site.register(CustomerBeneficaries)