from django.contrib import admin
from globalapp2.models import PhoneNumber

from globalapp2.models import Beneficaries



# Register your models here.
admin.site.register(Beneficaries)
admin.site.register(PhoneNumber)