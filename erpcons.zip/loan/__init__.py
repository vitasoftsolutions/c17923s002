# myapp/__init__.py
default_app_config = 'loan.apps.LoanConfig'  # Replace 'myapp' with your app's name
