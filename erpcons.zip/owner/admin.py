from django.contrib import admin

from owner.models import OwnerBeneficaries

# Register your models here.
admin.site.register(OwnerBeneficaries)