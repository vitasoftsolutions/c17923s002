from django.contrib import admin

from globalapp.models import Beneficaries



# Register your models here.
admin.site.register(Beneficaries)