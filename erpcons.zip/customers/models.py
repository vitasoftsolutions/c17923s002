from django.db import models

from globalapp2.models import Beneficaries

# Create your models here.
class CustomerBeneficaries(Beneficaries):
    pass